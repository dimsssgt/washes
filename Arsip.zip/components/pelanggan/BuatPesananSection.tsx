"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Button from "@/components/ui/Button";
import Field from "@/components/ui/Field";
import {
  ambilKatalog,
  buatPesanan,
  type ItemKatalog,
  type Katalog,
  type LayananKode,
  type WaktuCuci,
} from "@/lib/pelanggan/actions";

type MetodePengantaran = "antar-jemput" | "drop-mandiri";

const tabLabels: Record<LayananKode, string> = {
  kiloan: "Kiloan",
  satuan: "Satuan",
  linen: "Linen",
};

const tabInfo: Record<LayananKode, string> = {
  kiloan: "Kiloan dihitung per kg, minimal 3 kg. Berat final ditentukan petugas saat penimbangan.",
  satuan: "Satuan dihitung per item, tanpa minimal. Isi jumlah tiap jenis pakaian yang ingin dicuci.",
  linen: "Linen dihitung per item atau per meter, tanpa minimal. Isi jumlah tiap jenis yang ingin dicuci.",
};

function formatRupiah(n: number) {
  return "Rp " + n.toLocaleString("id-ID");
}

export default function BuatPesananSection() {
  const [katalog, setKatalog] = useState<Katalog | null>(null);
  const [errorKatalog, setErrorKatalog] = useState("");
  const [tab, setTab] = useState<LayananKode>("kiloan");
  const [metode, setMetode] = useState<MetodePengantaran>("antar-jemput");
  const [kecepatanId, setKecepatanId] = useState("");
  const [tanggalJemput, setTanggalJemput] = useState("");
  const [jamJemput, setJamJemput] = useState("");
  const [alamat, setAlamat] = useState("");
  const [catatan, setCatatan] = useState("");
  const [loading, setLoading] = useState(false);
  const [showKonfirmasi, setShowKonfirmasi] = useState(false);
  const [showTerkirim, setShowTerkirim] = useState(false);
  const [lastOrderCode, setLastOrderCode] = useState("");

  // State kuantitas per item
  const [itemCounts, setItemCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    ambilKatalog().then((hasil) => {
      if (hasil.ok) setKatalog(hasil.katalog);
      else setErrorKatalog(hasil.error);
    });
  }, []);

  // Pilihan kecepatan untuk tab yang sedang aktif, urut durasi terpanjang dulu
  const opsiKecepatan: WaktuCuci[] = katalog
    ? katalog.waktu.filter((w) => katalog.waktuPerLayanan[tab].includes(w.id))
    : [];
  const kecepatanAktif: WaktuCuci | undefined =
    opsiKecepatan.find((k) => k.id === kecepatanId) ?? opsiKecepatan[0];

  function defaultKecepatan(t: LayananKode): string {
    if (!katalog) return "";
    const pilihan = katalog.waktu.filter((w) => katalog.waktuPerLayanan[t].includes(w.id));
    return pilihan[0]?.id ?? "";
  }

  // Kolom tabel item: Reguler (72 jam) dan Express (24 jam)
  const waktuReguler = opsiKecepatan.find((k) => k.durasiJam === 72);
  const waktuExpress = opsiKecepatan.find((k) => k.durasiJam === 24);

  function updateCount(id: string, delta: number) {
    setItemCounts((prev) => {
      const cur = prev[id] || 0;
      const next = Math.max(0, cur + delta);
      return { ...prev, [id]: next };
    });
  }

  function setCountDirect(id: string, val: string) {
    const num = parseInt(val, 10);
    setItemCounts((prev) => ({
      ...prev,
      [id]: isNaN(num) || num < 0 ? 0 : num,
    }));
  }

  function hargaItem(item: ItemKatalog, waktuId: string | undefined): number {
    if (!waktuId) return 0;
    return item.hargaPerWaktu[waktuId] ?? 0;
  }

  // Hitung total item & total biaya (untuk Linen & Satuan)
  const currentList: ItemKatalog[] =
    katalog && tab !== "kiloan" ? katalog.items[tab] : [];
  const totalItemCount = currentList.reduce((sum, item) => sum + (itemCounts[item.id] || 0), 0);
  const totalEstimasiHarga = currentList.reduce((sum, item) => {
    const count = itemCounts[item.id] || 0;
    return sum + count * hargaItem(item, kecepatanAktif?.id);
  }, 0);

  async function handleKirim(e: React.FormEvent) {
    e.preventDefault();

    if ((tab === "linen" || tab === "satuan") && totalItemCount === 0) {
      alert("Pilih minimal 1 item barang yang ingin dicuci!");
      return;
    }

    setShowKonfirmasi(true);
  }

  async function handleKonfirmasiKirim() {
    if (loading || !katalog) return;

    if (!kecepatanAktif) {
      alert("Pilihan kecepatan belum tersedia. Silakan coba lagi.");
      return;
    }

    setLoading(true);
    const hasil = await buatPesanan({
      layananId: katalog.layananId[tab],
      waktuCuciId: kecepatanAktif.id,
      metode,
      alamat,
      jamJemput,
      catatan,
    });
    setLoading(false);
    setShowKonfirmasi(false);

    if (!hasil.ok) {
      alert(hasil.error);
      return;
    }

    setLastOrderCode(hasil.kode);
    setShowTerkirim(true);
  }

  if (!katalog) {
    return (
      <section
        id="buat-pesanan"
        style={{
          background: "#fff",
          border: "2px solid #0B2A6B",
          borderRadius: 18,
          boxShadow: "5px 5px 0 #0B2A6B",
          padding: 28,
          color: "#0B2A6B",
          fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif",
          fontSize: 13,
        }}
      >
        {errorKatalog || "Memuat layanan..."}
      </section>
    );
  }

  return (
    <>
      <section
        id="buat-pesanan"
        style={{
          background: "#fff",
          border: "2px solid #0B2A6B",
          borderRadius: 18,
          boxShadow: "5px 5px 0 #0B2A6B",
          padding: 28,
          color: "#0B2A6B",
        }}
      >
        <h2
          style={{
            fontFamily: "'Archivo Black', Impact, sans-serif",
            textTransform: "uppercase",
            letterSpacing: "-0.01em",
            lineHeight: 1,
            fontSize: 24,
            color: "#1457D6",
            marginBottom: 16,
          }}
        >
          Buat pesanan
        </h2>

        {/* Tab pilih layanan */}
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 8 }}>
          {(Object.keys(tabLabels) as LayananKode[]).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => {
                setTab(t);
                setItemCounts({});
                setKecepatanId(defaultKecepatan(t));
              }}
              style={{
                display: "inline-block",
                border: "2px solid #0B2A6B",
                borderRadius: 999,
                padding: "8px 16px",
                fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif",
                fontSize: 12,
                fontWeight: 700,
                whiteSpace: "nowrap",
                cursor: "pointer",
                background: tab === t ? "#1457D6" : "#FFF4DE",
                color: tab === t ? "#fff" : "#0B2A6B",
                transition: "background 0.15s, color 0.15s",
              }}
            >
              {tabLabels[t]}
            </button>
          ))}
        </div>

        <p style={{ fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif", fontSize: 12, margin: "12px 0 0" }}>
          {tabInfo[tab]}
        </p>

        {/* TABEL ITEM (HANYA MUNCUL DI TAB LINEN & SATUAN) */}
        {(tab === "linen" || tab === "satuan") && (
          <div
            style={{
              marginTop: 16,
              background: "#fff",
              border: "2px solid #0B2A6B",
              borderRadius: 14,
              padding: 16,
            }}
          >
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", minWidth: 460, borderCollapse: "collapse" }}>
                <thead>
                  <tr>
                    <th style={{ textAlign: "left", padding: "10px", borderBottom: "2px dashed #C9B98F", fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif", fontSize: 11, textTransform: "uppercase" }}>
                      Jenis
                    </th>
                    <th style={{ textAlign: "left", padding: "10px", borderBottom: "2px dashed #C9B98F", fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif", fontSize: 11, textTransform: "uppercase" }}>
                      Reguler 3 hari
                    </th>
                    <th style={{ textAlign: "left", padding: "10px", borderBottom: "2px dashed #C9B98F", fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif", fontSize: 11, textTransform: "uppercase" }}>
                      Express
                    </th>
                    <th style={{ textAlign: "center", padding: "10px", borderBottom: "2px dashed #C9B98F", fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif", fontSize: 11, textTransform: "uppercase" }}>
                      Jumlah
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {currentList.map((item) => {
                    const count = itemCounts[item.id] || 0;
                    const isReguler = kecepatanAktif?.id === waktuReguler?.id;
                    const isExpress = kecepatanAktif?.id === waktuExpress?.id;
                    return (
                      <tr key={item.id}>
                        <td style={{ padding: "12px 10px", borderBottom: "2px dashed #C9B98F", fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif", fontSize: 13, fontWeight: 700 }}>
                          {item.nama}
                        </td>
                        <td style={{ padding: "12px 10px", borderBottom: "2px dashed #C9B98F", fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif", fontSize: 13, color: isReguler ? "#1457D6" : "inherit", fontWeight: isReguler ? 700 : "normal" }}>
                          {formatRupiah(hargaItem(item, waktuReguler?.id))}
                        </td>
                        <td style={{ padding: "12px 10px", borderBottom: "2px dashed #C9B98F", fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif", fontSize: 13, color: isExpress ? "#1457D6" : "inherit", fontWeight: isExpress ? 700 : "normal" }}>
                          {formatRupiah(hargaItem(item, waktuExpress?.id))}
                        </td>
                        <td style={{ padding: "12px 10px", borderBottom: "2px dashed #C9B98F", textAlign: "center" }}>
                          <div style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                            <button
                              type="button"
                              onClick={() => updateCount(item.id, -1)}
                              style={{
                                width: 30,
                                height: 30,
                                borderRadius: 8,
                                border: "2px solid #0B2A6B",
                                background: "#FFF4DE",
                                cursor: "pointer",
                                fontWeight: 700,
                                fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif",
                              }}
                            >
                              -
                            </button>
                            <input
                              type="number"
                              min={0}
                              value={count}
                              onChange={(e) => setCountDirect(item.id, e.target.value)}
                              style={{
                                width: 50,
                                minHeight: 34,
                                textAlign: "center",
                                padding: "4px",
                                border: "2px solid #0B2A6B",
                                borderRadius: 8,
                                fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif",
                                fontSize: 13,
                                fontWeight: 700,
                              }}
                            />
                            <button
                              type="button"
                              onClick={() => updateCount(item.id, 1)}
                              style={{
                                width: 30,
                                height: 30,
                                borderRadius: 8,
                                border: "2px solid #0B2A6B",
                                background: "#FFD21F",
                                cursor: "pointer",
                                fontWeight: 700,
                                fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif",
                              }}
                            >
                              +
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Total Box */}
            <div
              style={{
                marginTop: 14,
                padding: "12px 16px",
                background: "#EEF2F7",
                borderRadius: 10,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif",
                fontSize: 13,
                flexWrap: "wrap",
                gap: 8,
              }}
            >
              <span>Total item: <b>{totalItemCount} barang</b></span>
              <span>Estimasi biaya: <b style={{ fontSize: 16, color: "#1457D6" }}>{formatRupiah(totalEstimasiHarga)}</b></span>
            </div>
          </div>
        )}

        <form onSubmit={handleKirim} style={{ marginTop: 20 }}>
          <div style={{ display: "flex", flexDirection: "column" }}>
            {/* Kecepatan */}
            <Field label="Kecepatan" id="kecepatan">
              <select
                value={kecepatanAktif?.id ?? ""}
                onChange={(e) => setKecepatanId(e.target.value)}
              >
                {opsiKecepatan.map((k) => (
                  <option key={k.id} value={k.id}>
                    {k.nama}
                  </option>
                ))}
              </select>
            </Field>

            {/* Metode Pengantaran (tepat di bawah Kecepatan) */}
            <div style={{ marginTop: 14 }}>
              <label
                style={{
                  display: "block",
                  fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif",
                  fontSize: 12,
                  fontWeight: 700,
                  textTransform: "uppercase",
                  color: "#0B2A6B",
                  marginBottom: 6,
                }}
              >
                Metode pengantaran
              </label>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {(["antar-jemput", "drop-mandiri"] as MetodePengantaran[]).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMetode(m)}
                    style={{
                      display: "inline-block",
                      border: "2px solid #0B2A6B",
                      borderRadius: 999,
                      padding: "8px 16px",
                      fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif",
                      fontSize: 12,
                      fontWeight: 700,
                      whiteSpace: "nowrap",
                      cursor: "pointer",
                      background: metode === m ? "#1457D6" : "#fff",
                      color: metode === m ? "#fff" : "#0B2A6B",
                      transition: "background 0.15s, color 0.15s",
                    }}
                  >
                    {m === "antar-jemput" ? "Antar jemput" : "Drop mandiri"}
                  </button>
                ))}
              </div>
            </div>

            {/* Hanya jika Antar Jemput: Tanggal Jemput (Hari), Jam Jemput, dan Alamat */}
            {metode === "antar-jemput" && (
              <>
                <Field label="Tanggal jemput" id="tanggalJemput">
                  <input
                    type="date"
                    value={tanggalJemput}
                    onChange={(e) => setTanggalJemput(e.target.value)}
                    min={new Date().toISOString().split("T")[0]}
                  />
                </Field>

                <Field label="Jam jemput" id="jamJemput">
                  <input
                    type="time"
                    value={jamJemput}
                    onChange={(e) => setJamJemput(e.target.value)}
                  />
                </Field>

                <Field label="Alamat jemput" id="alamat">
                  <textarea
                    rows={3}
                    value={alamat}
                    onChange={(e) => setAlamat(e.target.value)}
                    placeholder="Jl. ..."
                  />
                </Field>
              </>
            )}

            {/* Catatan (opsional) */}
            <Field label="Catatan (opsional)" id="catatan">
              <textarea
                rows={3}
                value={catatan}
                onChange={(e) => setCatatan(e.target.value)}
                placeholder="Cth: tanpa parfum"
              />
            </Field>
          </div>

          <div style={{ marginTop: 24, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 16 }}>
            <span style={{ fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif", fontSize: 13, color: "#0B2A6B" }}>
              {tab === "kiloan"
                ? "Total dihitung otomatis setelah penimbangan berat cucian."
                : "Total dihitung otomatis dari jumlah item."}
            </span>
            <Button type="submit" loading={loading}>
              Kirim pesanan
            </Button>
          </div>
        </form>
      </section>

      {/* Modal KonfirmasiKirimPesanan */}
      {showKonfirmasi && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto"
          style={{
            background: "rgba(51,71,126,0.85)",
            padding: "40px 16px",
            display: "flex",
            justifyContent: "center",
            alignItems: "flex-start",
            zIndex: 9999,
            WebkitOverflowScrolling: "touch",
          }}
          onClick={() => setShowKonfirmasi(false)}
        >
          <div
            style={{
              background: "#fff",
              border: "2px solid #0B2A6B",
              borderRadius: 18,
              boxShadow: "5px 5px 0 #0B2A6B",
              padding: 28,
              maxWidth: 400,
              width: "100%",
              margin: "auto 0",
              fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif",
              color: "#0B2A6B",
            }}
          >
            <h2
              style={{
                fontFamily: "'Archivo Black', Impact, sans-serif",
                textTransform: "uppercase",
                fontSize: 20,
                color: "#1457D6",
                marginBottom: 12,
              }}
            >
              Konfirmasi kirim pesanan
            </h2>
            <p style={{ fontSize: 13, marginBottom: 16 }}>
              Pastikan detail pesananmu sudah benar. Pesanan yang sudah dikirim akan masuk ke antrian.
            </p>

            <div style={{ background: "#EEF2F7", padding: "12px 14px", borderRadius: 12, marginBottom: 20, fontSize: 13 }}>
              <div>Layanan: <b>Cuci {tabLabels[tab]} ({kecepatanAktif?.nama ?? "-"})</b></div>
              {tab !== "kiloan" && <div>Jumlah: <b>{totalItemCount} item ({formatRupiah(totalEstimasiHarga)})</b></div>}
              <div>Metode: <b>{metode === "antar-jemput" ? "Antar Jemput" : "Drop Mandiri"}</b></div>
            </div>

            <div style={{ display: "flex", justifyContent: "flex-end", gap: 10 }}>
              <Button variant="yellow" size="sm" onClick={() => setShowKonfirmasi(false)}>
                Cek lagi
              </Button>
              <Button size="sm" loading={loading} onClick={handleKonfirmasiKirim}>
                Ya, kirim
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Pesanan Terkirim */}
      {showTerkirim && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto"
          style={{
            background: "rgba(51,71,126,0.85)",
            padding: "40px 16px",
            display: "flex",
            justifyContent: "center",
            alignItems: "flex-start",
            zIndex: 9999,
            WebkitOverflowScrolling: "touch",
          }}
          onClick={() => setShowTerkirim(false)}
        >
          <div
            style={{
              width: "100%",
              maxWidth: 420,
              margin: "auto 0",
              background: "#fff",
              border: "2px solid #0B2A6B",
              borderRadius: 18,
              boxShadow: "5px 5px 0 #0B2A6B",
              padding: 28,
              boxSizing: "border-box",
              color: "#0B2A6B",
              fontFamily: "var(--font-poppins), 'Poppins', Arial, sans-serif",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, marginBottom: 8 }}>
              <h2 style={{ fontFamily: "'Archivo Black', Impact, sans-serif", textTransform: "uppercase", fontSize: 22, color: "#1457D6", margin: 0 }}>
                Pesanan terkirim
              </h2>
              <button
                onClick={() => setShowTerkirim(false)}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  background: "#FFD21F",
                  color: "#0B2A6B",
                  border: "none",
                  borderRadius: 999,
                  minHeight: 40,
                  width: 44,
                  cursor: "pointer",
                  fontFamily: "'Archivo Black', sans-serif",
                  fontSize: 13,
                  boxShadow: "inset 0 0 0 2px #0B2A6B",
                }}
              >
                ✕
              </button>
            </div>

            <div style={{ textAlign: "center", margin: "14px 0" }}>
              <span
                style={{
                  display: "inline-block",
                  border: "2px solid #0B2A6B",
                  borderRadius: 999,
                  padding: "8px 22px",
                  fontSize: 26,
                  fontWeight: 700,
                  background: "#12805C",
                  color: "#fff",
                }}
              >
                ✔
              </span>
            </div>

            <p style={{ margin: "0 0 16px", textAlign: "center", fontSize: 13 }}>
              {metode === "antar-jemput"
                ? "Pesananmu sudah kami terima. Kurir akan menjemput sesuai jadwal."
                : "Pesananmu sudah kami catat. Silakan antar cucianmu ke outlet kami."}
            </p>

            <div style={{ marginTop: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: "10px 0", borderBottom: "2px dashed #C9B98F", fontSize: 13 }}>
                <span>Kode pesanan</span>
                <b style={{ textAlign: "right" }}>{lastOrderCode}</b>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: "10px 0", borderBottom: "2px dashed #C9B98F", fontSize: 13 }}>
                <span>Layanan</span>
                <b style={{ textAlign: "right" }}>{tabLabels[tab]} · {kecepatanAktif?.nama ?? "-"}</b>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: "10px 0", borderBottom: "2px dashed #C9B98F", fontSize: 13 }}>
                <span>Metode</span>
                <b style={{ textAlign: "right" }}>{metode === "antar-jemput" ? "Antar Jemput" : "Drop Mandiri"}</b>
              </div>
              {metode === "antar-jemput" && (
                <div style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: "10px 0", borderBottom: "2px dashed #C9B98F", fontSize: 13 }}>
                  <span>Jadwal jemput</span>
                  <b style={{ textAlign: "right" }}>
                    {tanggalJemput || "Hari ini"}{jamJemput ? `, ${jamJemput}` : ""}
                  </b>
                </div>
              )}
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: "10px 0", borderBottom: "2px dashed #C9B98F", fontSize: 13 }}>
                <span>Harga</span>
                <b style={{ textAlign: "right" }}>
                  {tab === "kiloan" ? "Dihitung setelah ditimbang" : formatRupiah(totalEstimasiHarga)}
                </b>
              </div>
            </div>

            <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, flexWrap: "wrap", marginTop: 24 }}>
              <Button variant="yellow" size="sm" onClick={() => setShowTerkirim(false)}>
                Tutup
              </Button>
              <Link href="/pelanggan/aktif">
                <Button size="sm">
                  Lihat pesanan aktif
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </>
  );
}